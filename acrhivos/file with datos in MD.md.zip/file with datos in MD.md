##1.-Indroduccion brece y contexalizacion
---




##2.-Desarrollo técnico correcto y preciso
---
1.
```

```

2.
```

       
```
3.
```

```
4.
```
 

```
5.
```
 

```
6.
```
  
```

##-3.-Aplicacion practica
---
```

```

##4.-Cierre/Conclusión enlazando con la unidad
---
